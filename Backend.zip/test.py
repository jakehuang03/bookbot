import db.crud as crud
print(crud.get_comment_by_questionid(1))
